package com.company;

public interface Peliharaan {
    public void latihan();
    public void beriMakan();
}
