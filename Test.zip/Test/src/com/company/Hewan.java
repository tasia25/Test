package com.company;

public class Hewan {
    private int usia;
    private String perasaan;

    public void tambahUsia(){
        usia++;
        if(usia>10){
            System.out.println("Mati");
        }else {
            System.out.println(getUsia());
        }
    }

    public void bersuara(String suara){
        System.out.println(suara);
    }

    public int getUsia() {
        return usia;
    }

    public void setUsia(int usia) {
        this.usia = usia;
    }

    public String getPerasaan() {
        return perasaan;
    }

    public void setPerasaan(String perasaan) {
        this.perasaan = perasaan;
    }
}
