package com.company;

public class Hamster extends Hewan implements Peliharaan{
    @Override
    public void latihan() {
        System.out.println("Lari di kandang");
    }

    @Override
    public void beriMakan() {
        System.out.println("Beri makan biji bunga Matahari");
    }

    public void bergulingGuling(){
        System.out.println("Hamster sedang berguling....");
    }
}
