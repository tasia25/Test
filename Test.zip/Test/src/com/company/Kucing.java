package com.company;

public class Kucing extends Hewan implements Peliharaan {

    @Override
    public void latihan() {
        System.out.println("Duduk");
    }

    @Override
    public void beriMakan() {
        System.out.println("Kucing diberi ikan dan kenyang");
    }

    public void menjilat(){
        System.out.println("Kucing sedang menjilat");
    }

}
