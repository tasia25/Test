package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Kucing persia = new Kucing();
        persia.latihan();
        persia.beriMakan();

        Beruang polarBear = new Beruang();
        polarBear.tambahUsia();
        polarBear.tambahUsia();

        Hamster hamtaro = new Hamster();
        hamtaro.latihan();
        hamtaro.setPerasaan("Lelah");
        System.out.println(hamtaro.getPerasaan());
        hamtaro.beriMakan();
        hamtaro.setPerasaan("Senang");
        System.out.println(hamtaro.getPerasaan());
    }
}
