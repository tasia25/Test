package com.company;

public class Beruang extends Hewan {

    public void mencariMakan(){
        System.out.println("Beruang sedang mencari makan...");
    }
}
